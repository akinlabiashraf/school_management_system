<?php $this->view('includes/header') ?>


<body>

	<!-- Main Wrapper -->
	<div class="main-wrapper">

		<?php $this->view('includes/header_nav') ?>

		<!-- Breadcrumb -->
		<?php $this->view('includes/crumbs') ?>
		<div class="breadcrumb-bar text-center">
			<div class="container">
				<div class="row">
					<div class="col-md-12 col-12">
						<h2 class="breadcrumb-title mb-2">All Tests</h2>
						<?php $this->view('includes/crumbs', ['crumbs' => $crumbs]) ?>
					</div>
				</div>
			</div>
		</div>
		<!-- /Breadcrumb -->

		<div class="content">
			<div class="container">
				<!-- profile box -->
				<div class="instructor-profile">
					<div class="instructor-profile-bg">
						<img src="assets/img/bg/card-bg-01.png" class="instructor-profile-bg-1" alt="">
					</div>
					<div class="row align-items-center row-gap-3">
						<div class="col-md-6">
							<div class="d-flex align-items-center">
								<span class="avatar flex-shrink-0 avatar-xxl avatar-rounded me-3 border border-white border-3 position-relative">
									<img src="assets/img/user/user-01.jpg" alt="img">
									<span class="verify-tick"><i class="isax isax-verify5"></i></span>
								</span>
								<div>
									<h5 class="mb-1 text-white d-inline-flex align-items-center"><?= Auth::getfirst_name() . " " . Auth::getlast_name() ?><a href="instructor-profile.html" class="link-light fs-16 ms-2"><i class="isax isax-edit-2"></i></a></h5>
									<p class="text-light"><?= ucfirst(str_replace("_", " ", Auth::getranks())) ?></p>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="d-flex align-items-center flex-wrap gap-3 justify-content-md-end">
								<!-- <?php if (Auth::access('lecturer')): ?>
                                    <?php
											$link = ROOT . "/single_class/testadd/" . $row->class_id . "?tab=test-add";
									?>
                                    <a href="<?= $link ?>" class="btn btn-white rounded-pill">Add New Test</a>

                                <?php endif; ?> -->

								<?php if (Auth::access('lecturer')): ?>
									<a href="#" class="btn btn-white rounded-pill">Add Course</a>
								<?php endif; ?>
								<a href="#" class="btn btn-secondary rounded-pill">Dashboard</a>
							</div>
						</div>
					</div>
				</div>
				<!-- profile box -->
				<div class="row">
					<!-- sidebar -->

					<?php $this->view('includes/admin_sidenav') ?>

					<!-- sidebar -->
					<div class="col-lg-9 quiz-wizard">
						<fieldset id="first-field">
							<div class="page-title d-flex align-items-center justify-content-between">
								<h5>My Quiz Attempts</h5>
							</div>
							<div class="quiz-attempt-card border-0">
								<div class="quiz-attempt-body p-0">
									<div class="border p-3 mb-3 rounded-2">
										<div class="bg-light border p-3 mb-3 rounded-2 flex-wrap">
											<div class="row align-items-center">
												<div class="col-md-8">
													<div class="mb-2 mb-md-0">
														<div class="d-flex align-items-center">
															<div class="avatar avatar-lg me-3 flex-shrink-0">
																<img class="img-fluid rounded-3" src="assets/img/students/quiz.jpg" alt="">
															</div>
															<h5 class="fs-18">Information About UI/UX Design Degree</h5>
														</div>
													</div>
												</div>
												<div class="col-md-4">
													<div class="text-md-end">
														<p class="d-inline-flex align-items-center mb-0">
															<i class="isax isax-clock me-1"></i>
															00:02:21
															<span class="text-dark ms-1"> / 00:03:00</span>
														</p>
													</div>
												</div>
											</div>
										</div>
										<div class="mb-3">
											<div class="d-flex align-items-center justify-content-between mb-1">
												<span class="fw-semibold text-gray-9">Quiz Progress</span>
												<span>Question 1 out of 5</span>
											</div>
											<div class="progress progress-xs  flex-grow-1 mb-1">
												<div class="progress-bar bg-success rounded" role="progressbar" style="width: 20%;" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100"></div>
											</div>
										</div>
										<div class="mb-0">
											<h6 class="mb-3">What does UI stand for?</h6>
											<div class="form-check mb-2">
												<input class="form-check-input" type="radio" name="qusetion-1" id="Radio-sm-1">
												<label class="form-check-label" for="Radio-sm-1">
													User Intention
												</label>
											</div>
											<div class="form-check mb-2">
												<input class="form-check-input" type="radio" name="qusetion-1" id="Radio-sm-2">
												<label class="form-check-label" for="Radio-sm-2">
													User Interface
												</label>
											</div>
											<div class="form-check mb-2">
												<input class="form-check-input" type="radio" name="qusetion-1" id="Radio-sm-3">
												<label class="form-check-label" for="Radio-sm-3">
													Universal Interaction
												</label>
											</div>
											<div class="form-check mb-0">
												<input class="form-check-input" type="radio" name="qusetion-1" id="Radio-sm-4">
												<label class="form-check-label" for="Radio-sm-4">
													Usability Information
												</label>
											</div>
										</div>
									</div>
									<div class="text-end">
										<button type="button" class="btn btn-secondary rounded-pill next_btn">Next<i class="isax isax-arrow-right-3 ms-1 fs-10"></i></button>
									</div>
								</div>
							</div>

						</fieldset>

						<fieldset>
							<div class="page-title d-flex align-items-center justify-content-between">
								<h5>My Quiz Attempts</h5>
							</div>
							<div class="quiz-attempt-card border-0">
								<div class="quiz-attempt-body p-0">
									<div class="border p-3 mb-3 rounded-2">
										<div class="bg-light border p-3 mb-3 rounded-2 flex-wrap">
											<div class="row align-items-center">
												<div class="col-md-8">
													<div class="mb-2 mb-md-0">
														<div class="d-flex align-items-center">
															<div class="avatar avatar-lg me-3 flex-shrink-0">
																<img class="img-fluid rounded-3" src="assets/img/students/quiz.jpg" alt="">
															</div>
															<h5 class="fs-18">Information About UI/UX Design Degree</h5>
														</div>
													</div>
												</div>
												<div class="col-md-4">
													<div class="text-md-end">
														<p class="d-inline-flex align-items-center mb-0">
															<i class="isax isax-clock me-1"></i>
															00:02:21
															<span class="text-dark ms-1"> / 00:03:00</span>
														</p>
													</div>
												</div>
											</div>
										</div>
										<div class="mb-3">
											<div class="d-flex align-items-center justify-content-between mb-1">
												<span class="fw-semibold text-gray-9">Quiz Progress</span>
												<span>Question 2 out of 5</span>
											</div>
											<div class="progress progress-xs  flex-grow-1 mb-1">
												<div class="progress-bar bg-success rounded" role="progressbar" style="width: 40%;" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100"></div>
											</div>
										</div>
										<div class="mb-0">
											<h6 class="mb-3">Which of the following is a principle of UX design?</h6>
											<div class="form-check mb-2">
												<input class="form-check-input" type="radio" name="qusetion-2" id="Radio-sm-5">
												<label class="form-check-label" for="Radio-sm-5">
													Minimalistic Design
												</label>
											</div>
											<div class="form-check mb-2">
												<input class="form-check-input" type="radio" name="qusetion-2" id="Radio-sm-6">
												<label class="form-check-label" for="Radio-sm-6">
													User-Centered Design
												</label>
											</div>
											<div class="form-check mb-2">
												<input class="form-check-input" type="radio" name="qusetion-2" id="Radio-sm-7">
												<label class="form-check-label" for="Radio-sm-7">
													Gradient Usage
												</label>
											</div>
											<div class="form-check mb-0">
												<input class="form-check-input" type="radio" name="qusetion-2" id="Radio-sm-8">
												<label class="form-check-label" for="Radio-sm-8">
													Typography Hierarchy
												</label>
											</div>
										</div>
									</div>
									<div class="d-flex align-items-center justify-content-between">
										<a href="javascript:void(0);" class="btn bg-gray-100 d-inline-flex rounded-pill align-items-center prev_btn me-1"><i class="isax isax-arrow-left-2 me-1 fs-10"></i>Previous</a>
										<button type="button" class="btn btn-secondary rounded-pill next_btn">Next<i class="isax isax-arrow-right-3 ms-1 fs-10"></i></button>
									</div>
								</div>
							</div>
						</fieldset>
						<fieldset>
							<div class="page-title d-flex align-items-center justify-content-between">
								<h5>My Quiz Attempts</h5>
							</div>
							<div class="quiz-attempt-card border-0">
								<div class="quiz-attempt-body p-0">
									<div class="border p-3 mb-3 rounded-2">
										<div class="bg-light border p-3 mb-3 rounded-2 flex-wrap">
											<div class="row align-items-center">
												<div class="col-md-8">
													<div class="mb-2 mb-md-0">
														<div class="d-flex align-items-center">
															<div class="avatar avatar-lg me-3 flex-shrink-0">
																<img class="img-fluid rounded-3" src="assets/img/students/quiz.jpg" alt="">
															</div>
															<h5 class="fs-18">Information About UI/UX Design Degree</h5>
														</div>
													</div>
												</div>
												<div class="col-md-4">
													<div class="text-md-end">
														<p class="d-inline-flex align-items-center mb-0">
															<i class="isax isax-clock me-1"></i>
															00:02:21
															<span class="text-dark ms-1"> / 00:03:00</span>
														</p>
													</div>
												</div>
											</div>
										</div>
										<div class="mb-3">
											<div class="d-flex align-items-center justify-content-between mb-1">
												<span class="fw-semibold text-gray-9">Quiz Progress</span>
												<span>Question 3 out of 5</span>
											</div>
											<div class="progress progress-xs  flex-grow-1 mb-1">
												<div class="progress-bar bg-success rounded" role="progressbar" style="width: 60%;" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"></div>
											</div>
										</div>
										<div class="mb-0">
											<h6 class="mb-3">Which tool is commonly used for wireframing?</h6>
											<div class="form-check mb-2">
												<input class="form-check-input" type="radio" name="qusetion-3" id="Radio-sm-9">
												<label class="form-check-label" for="Radio-sm-9">
													Adobe Photoshop
												</label>
											</div>
											<div class="form-check mb-2">
												<input class="form-check-input" type="radio" name="qusetion-3" id="Radio-sm-10">
												<label class="form-check-label" for="Radio-sm-10">
													Figma
												</label>
											</div>
											<div class="form-check mb-2">
												<input class="form-check-input" type="radio" name="qusetion-3" id="Radio-sm-11">
												<label class="form-check-label" for="Radio-sm-11">
													Visual Studio Code
												</label>
											</div>
											<div class="form-check mb-0">
												<input class="form-check-input" type="radio" name="qusetion-3" id="Radio-sm-12">
												<label class="form-check-label" for="Radio-sm-12">
													GitHub
												</label>
											</div>
										</div>
									</div>
									<div class="d-flex align-items-center justify-content-between">
										<a href="javascript:void(0);" class="btn bg-gray-100 d-inline-flex rounded-pill align-items-center prev_btn me-1"><i class="isax isax-arrow-left-2 me-1 fs-10"></i>Previous</a>
										<button type="button" class="btn btn-secondary rounded-pill next_btn">Next<i class="isax isax-arrow-right-3 ms-1 fs-10"></i></button>
									</div>
								</div>
							</div>
						</fieldset>
						<fieldset>
							<div class="page-title d-flex align-items-center justify-content-between">
								<h5>My Quiz Attempts</h5>
							</div>
							<div class="quiz-attempt-card border-0">
								<div class="quiz-attempt-body p-0">
									<div class="border p-3 mb-3 rounded-2">
										<div class="bg-light border p-3 mb-3 rounded-2 flex-wrap">
											<div class="row align-items-center">
												<div class="col-md-8">
													<div class="mb-2 mb-md-0">
														<div class="d-flex align-items-center">
															<div class="avatar avatar-lg me-3 flex-shrink-0">
																<img class="img-fluid rounded-3" src="assets/img/students/quiz.jpg" alt="">
															</div>
															<h5 class="fs-18">Information About UI/UX Design Degree</h5>
														</div>
													</div>
												</div>
												<div class="col-md-4">
													<div class="text-md-end">
														<p class="d-inline-flex align-items-center mb-0">
															<i class="isax isax-clock me-1"></i>
															00:02:21
															<span class="text-dark ms-1"> / 00:03:00</span>
														</p>
													</div>
												</div>
											</div>
										</div>
										<div class="mb-3">
											<div class="d-flex align-items-center justify-content-between mb-1">
												<span class="fw-bold text-gray-9">Quiz Progress</span>
												<span>Question 4 out of 5</span>
											</div>
											<div class="progress progress-xs  flex-grow-1 mb-1">
												<div class="progress-bar bg-success rounded" role="progressbar" style="width: 80%;" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100"></div>
											</div>
										</div>
										<div class="mb-0">
											<h6 class="mb-3">What is a wireframe?</h6>
											<div class="form-check mb-2">
												<input class="form-check-input" type="radio" name="qusetion-4" id="Radio-sm-13">
												<label class="form-check-label" for="Radio-sm-13">
													A detailed, interactive prototype
												</label>
											</div>
											<div class="form-check mb-2">
												<input class="form-check-input" type="radio" name="qusetion-4" id="Radio-sm-14">
												<label class="form-check-label" for="Radio-sm-14">
													A low-fidelity representation of a design
												</label>
											</div>
											<div class="form-check mb-2">
												<input class="form-check-input" type="radio" name="qusetion-4" id="Radio-sm-15">
												<label class="form-check-label" for="Radio-sm-15">
													The codebase of a website
												</label>
											</div>
											<div class="form-check mb-0">
												<input class="form-check-input" type="radio" name="qusetion-4" id="Radio-sm-16">
												<label class="form-check-label" for="Radio-sm-16">
													A high-fidelity design concept
												</label>
											</div>
										</div>
									</div>
									<div class="d-flex align-items-center justify-content-between">
										<a href="javascript:void(0);" class="btn btn-light d-inline-flex rounded-pill align-items-center prev_btn me-1"><i class="isax isax-arrow-left-2 me-1 fs-10"></i>Back</a>
										<button type="button" class="btn btn-secondary rounded-pill next_btn">Next<i class="isax isax-arrow-right-3 ms-1 fs-10"></i></button>
									</div>
								</div>
							</div>
						</fieldset>
						<fieldset>
							<div class="page-title d-flex align-items-center justify-content-between">
								<h5>My Quiz Attempts</h5>
							</div>
							<div class="quiz-attempt-card border-0">
								<div class="quiz-attempt-body p-0">
									<div class="border p-3 mb-3 rounded-2">
										<div class="bg-light border p-3 mb-3 rounded-2 flex-wrap">
											<div class="row align-items-center">
												<div class="col-md-8">
													<div class="mb-2 mb-md-0">
														<div class="d-flex align-items-center">
															<div class="avatar avatar-lg me-3 flex-shrink-0">
																<img class="img-fluid rounded-3" src="assets/img/students/quiz.jpg" alt="">
															</div>
															<h5 class="fs-18">Information About UI/UX Design Degree</h5>
														</div>
													</div>
												</div>
												<div class="col-md-4">
													<div class="text-md-end">
														<p class="d-inline-flex align-items-center mb-0">
															<i class="isax isax-clock me-1"></i>
															00:02:21
															<span class="text-dark ms-1"> / 00:03:00</span>
														</p>
													</div>
												</div>
											</div>
										</div>
										<div class="mb-3">
											<div class="d-flex align-items-center justify-content-between mb-1">
												<span class="fw-bold text-gray-9">Quiz Progress</span>
												<span>Question 5 out of 5</span>
											</div>
											<div class="progress progress-xs  flex-grow-1 mb-1">
												<div class="progress-bar bg-success rounded" role="progressbar" style="width: 100%;" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100"></div>
											</div>
										</div>
										<div class="mb-0">
											<h6 class="mb-3">What is the primary goal of UX design?</h6>
											<div class="form-check mb-2">
												<input class="form-check-input" type="radio" name="qusetion-4" id="Radio-sm-17">
												<label class="form-check-label" for="Radio-sm-17">
													To create a visually appealing design
												</label>
											</div>
											<div class="form-check mb-2">
												<input class="form-check-input" type="radio" name="qusetion-4" id="Radio-sm-18">
												<label class="form-check-label" for="Radio-sm-18">
													To enhance user satisfaction and usability
												</label>
											</div>
											<div class="form-check mb-2">
												<input class="form-check-input" type="radio" name="qusetion-4" id="Radio-sm-19">
												<label class="form-check-label" for="Radio-sm-19">
													To develop complex navigation flows
												</label>
											</div>
											<div class="form-check mb-0">
												<input class="form-check-input" type="radio" name="qusetion-4" id="Radio-sm-20">
												<label class="form-check-label" for="Radio-sm-20">
													To optimize code performance
												</label>
											</div>
										</div>
									</div>
									<div class="d-flex align-items-center justify-content-between">
										<a href="javascript:void(0);" class="btn bg-gray-100 d-inline-flex rounded-pill align-items-center prev_btn me-1"><i class="isax isax-arrow-left-2 me-1 fs-10"></i>Back</a>
										<button type="button" class="btn btn-secondary rounded-pill next_btn">Finish</button>
									</div>
								</div>
							</div>
						</fieldset>
						<fieldset>
							<div class="page-title d-flex align-items-center justify-content-between">
								<h5>My Quiz Attempts</h5>
							</div>
							<div class="card">
								<div class="card-body">
									<div class="quiz-circle-progress m-0 mb-3">
										<div class="circle-progress mb-2" data-value='80'>
											<span class="progress-left">
												<span class="progress-bar border-success"></span>
											</span>
											<span class="progress-right">
												<span class="progress-bar border-success"></span>
											</span>
											<div class="progress-value text-success fw-bold fs-24">80%</div>
										</div>
										<p class="text-center fs-14">Pass Score : 80%</p>
									</div>
									<div class="text-center mb-3">
										<h6 class="mb-1">Congratulations! You Passed</h6>
										<p class="fs-14">You’ve successfully passed the quiz. Keep up the great work!</p>
									</div>
									<div class="d-flex align-items-center justify-content-center">
										<a href="student-dashboard.html" class="btn btn-secondary rounded-pill"><i class="isax isax-arrow-left-2 me-1 fs-10"></i>Back to Dashboard</a>
									</div>
								</div>
							</div>
						</fieldset>
						<fieldset>
							<div class="page-title d-flex align-items-center justify-content-between">
								<h5>My Quiz Attempts</h5>
							</div>
							<div class="quiz-attempt-card">
								<div class="quiz-attempt-body">
									<div class="quiz-circle-progress m-0 mb-3">
										<div class="circle-progress mb-2" data-value='20'>
											<span class="progress-left">
												<span class="progress-bar border-danger"></span>
											</span>
											<span class="progress-right">
												<span class="progress-bar border-danger"></span>
											</span>
											<div class="progress-value text-danger fw-bold fs-24">20%</div>
										</div>
										<p class="text-center fs-14">Pass Score : 20%</p>
									</div>
									<div class="text-center mb-3">
										<h6 class="mb-1">Sorry, You Didn't Pass This Time</h6>
										<p class="fs-14">Don't worry, learn from this attempt and come back stronger next time!</p>
									</div>
									<div class="d-flex align-items-center justify-content-center">
										<a href="student-dashboard.html" class="btn btn-secondary rounded-pill"><i class="isax isax-arrow-left-2 me-1 fs-10"></i>Back to Dashboard</a>
									</div>
								</div>
							</div>
						</fieldset>
					</div>
				</div>
			</div>
		</div>

		<!-- Footer -->
		<footer class="footer">
			<div class="footer-bg">
				<img src="assets/img/bg/footer-bg-01.png" class="footer-bg-1" alt="">
				<img src="assets/img/bg/footer-bg-02.png" class="footer-bg-2" alt="">
			</div>
			<div class="footer-top">
				<div class="container">
					<div class="row row-gap-4">
						<div class="col-lg-4">
							<div class="footer-about">
								<div class="footer-logo">
									<img src="assets/img/logo.svg" alt="">
								</div>
								<p>Platform designed to help organizations, educators, and learners manage, deliver, and track learning and training activities.</p>
								<div class="d-flex align-items-center">
									<a href="#" class="me-2"><img src="assets/img/icon/appstore.svg" alt=""></a>
									<a href="#"><img src="assets/img/icon/googleplay.svg" alt=""></a>
								</div>
							</div>
						</div>
						<div class="col-lg-8">
							<div class="row row-gap-4">
								<div class="col-lg-3">
									<div class="footer-widget footer-menu">
										<h5 class="footer-title">For Instructor</h5>
										<ul>
											<li><a href="course-grid.html">Search Mentors</a></li>
											<li><a href="login.html">Login</a></li>
											<li><a href="register.html">Register</a></li>
											<li><a href="course-list.html">Booking</a></li>
											<li><a href="student-dashboard.html">Students Dashboard</a></li>
										</ul>
									</div>
								</div>
								<div class="col-lg-3">
									<div class="footer-widget footer-menu">
										<h5 class="footer-title">For Student</h5>
										<ul>
											<li><a href="javascript:void(0);">Appointments</a></li>
											<li><a href="instructor-message.html">Chat</a></li>
											<li><a href="login.html">Login</a></li>
											<li><a href="register.html">Register</a></li>
											<li><a href="instructor-dashboard.html">Instructor Dashboard</a></li>
										</ul>
									</div>
								</div>
								<div class="col-lg-6">
									<div class="footer-widget footer-contact">
										<h5 class="footer-title">Newsletter</h5>
										<div class="subscribe-input">
											<form action="javascript:void(0);">
												<input type="email" class="form-control" placeholder="Enter your Email Address">
												<button type="submit" class="btn btn-primary btn-sm inline-flex align-items-center"><i class="isax isax-send-2 me-1"></i>Subscribe</button>
											</form>
										</div>
										<div class="footer-contact-info">
											<div class="footer-address d-flex align-items-center">
												<img src="assets/img/icon/icon-20.svg" alt="Img" class="img-fluid me-2">
												<p> 3556 Beech Street, San Francisco,<br> California, CA 94108 </p>
											</div>
											<div class="footer-address d-flex align-items-center">
												<img src="assets/img/icon/icon-19.svg" alt="Img" class="img-fluid me-2">
												<p><a href="https://dreamslms.dreamstechnologies.com/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="2440564145495748495764415c45495448410a474b49">[email&#160;protected]</a></p>
											</div>
											<div class="footer-address d-flex align-items-center">
												<img src="assets/img/icon/icon-21.svg" alt="Img" class="img-fluid me-2">
												<p>+19 123-456-7890</p>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="footer-bottom">
				<div class="container">
					<div class="row row-gap-2">
						<div class="col-md-6">
							<div class="text-center text-md-start">
								<p class="text-white">Copyright &copy; 2025 DreamsLMS. All rights reserved.</p>
							</div>
						</div>
						<div class="col-md-6">
							<div>
								<ul class="d-flex align-items-center justify-content-center justify-content-md-end footer-link">
									<li><a href="terms-and-conditions.html">Terms & Conditions</a></li>
									<li><a href="privacy-policy.html">Privacy Policy</a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
		</footer>
		<!-- /Footer -->

		<!-- Edit Review -->
		<div class="modal fade" id="edit_review">
			<div class="modal-dialog modal-dialog-centered">
				<div class="modal-content">
					<div class="modal-header">
						<h4 class="modal-title">Edit Review</h4>
						<button type="button" class="btn-close custom-btn-close" data-bs-dismiss="modal" aria-label="Close">
							<i class="isax isax-close-circle"></i>
						</button>
					</div>
					<div class="modal-body pb-0">
						<div class="mb-3">
							<label class="form-label fs-14">Your Rating <span class="text-danger">*</span></label>
							<div class="selection-wrap">
								<div class="d-inline-block">
									<div class="rating-selction">
										<input type="radio" name="rating" value="5" id="rating5" checked>
										<label for="rating5"><i class="fa-solid fa-star"></i></label>
										<input type="radio" name="rating" value="4" id="rating4" checked>
										<label for="rating4"><i class="fa-solid fa-star"></i></label>
										<input type="radio" name="rating" value="3" id="rating3" checked>
										<label for="rating3"><i class="fa-solid fa-star"></i></label>
										<input type="radio" name="rating" value="2" id="rating2">
										<label for="rating2"><i class="fa-solid fa-star"></i></label>
										<input type="radio" name="rating" value="1" id="rating1">
										<label for="rating1"><i class="fa-solid fa-star"></i></label>
									</div>
								</div>
							</div>
						</div>
						<div class="mb-3">
							<label class="form-label fs-14">Write Your Review <span class="text-danger">*</span></label>
							<textarea class="form-control" rows="3">This is the second Photoshop course I have completed with Nancy Duarte. Worth every penny and recommend it highly. To get the most out of this course, its best to to take the Beginner to Advanced course first. The sound and video quality is of a good standard. Thank you Nancy Duarte.</textarea>
						</div>
					</div>
					<div class="modal-footer">
						<a href="javascript:void(0);" class="btn btn-md btn-light rounded-pill me-2" data-bs-dismiss="modal">Cancel</a>
						<button type="submit" class="btn btn-md btn-secondary rounded-pill">Save Changes</button>
					</div>
				</div>
			</div>
		</div>
		<!-- /Edit Review -->

		<!-- Delete Modal -->
		<div class="modal fade" id="delete_modal">
			<div class="modal-dialog modal-dialog-centered">
				<div class="modal-content">
					<div class="modal-body text-center custom-modal-body">
						<span class="avatar avatar-lg bg-light rounded-circle mb-2">
							<i class="isax isax-trash fs-24 text-danger"></i>
						</span>
						<div>
							<h4 class="mb-2">Delete Review</h4>
							<p class="mb-3">Are you sure you want to delete review?</p>
							<div class="d-flex align-items-center justify-content-center">
								<a href="#" class="btn btn-light rounded-pill me-2" data-bs-dismiss="modal">Cancel</a>
								<a href="#" class="btn btn-secondary rounded-pill">Yes, Remove All</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- /Delete Modal -->

	</div>
	<!-- /Main Wrapper -->

	<!-- jQuery -->
	<script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
	<script src="assets/js/jquery-3.7.1.min.js" type="bd021f487848e83a258706fa-text/javascript"></script>

	<!-- Bootstrap Core JS -->
	<script src="assets/js/bootstrap.bundle.min.js" type="bd021f487848e83a258706fa-text/javascript"></script>

	<!-- Sticky Sidebar JS -->
	<script src="assets/plugins/theia-sticky-sidebar/ResizeSensor.js" type="bd021f487848e83a258706fa-text/javascript"></script>
	<script src="assets/plugins/theia-sticky-sidebar/theia-sticky-sidebar.js" type="bd021f487848e83a258706fa-text/javascript"></script>

	<!-- Custom JS -->
	<script src="assets/js/script.js" type="bd021f487848e83a258706fa-text/javascript"></script>

	<script src="../../cdn-cgi/scripts/7d0fa10a/cloudflare-static/rocket-loader.min.js" data-cf-settings="bd021f487848e83a258706fa-|49" defer></script>
	<script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"rayId":"93f10eab09b79874","version":"2025.4.0-1-g37f21b1","serverTiming":{"name":{"cfExtPri":true,"cfL4":true,"cfSpeedBrain":true,"cfCacheStatus":true}},"token":"3ca157e612a14eccbb30cf6db6691c29","b":1}' crossorigin="anonymous"></script>
</body>

<!-- Mirrored from dreamslms.dreamstechnologies.com/html/template/student-quiz-questions.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 13 May 2025 09:17:22 GMT -->

</html>